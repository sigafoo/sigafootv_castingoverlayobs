to use one of the custom features:

1. open the folder of the feature you want to use
2. copy the contents (resource, scripts, or sometimes both) to the root directory
3. replace all the files when prompted
4. run tf2